package pack;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
 





import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;

import Models.UserModel;
 
@WebServlet("/upload")
@MultipartConfig(maxFileSize = 16177215)    // upload file's size up to 16MB
public class FileUploadServlet extends HttpServlet {
     
    private String dbURL = "jdbc:oracle:thin:@localhost:1522:xe";
    private String dbUser = "system";
    private String dbPass = "12345";
     
    protected void doPost(HttpServletRequest request,
            HttpServletResponse response) throws ServletException, IOException {
        	PrintWriter out=response.getWriter();
    	/*HttpSession session2=request.getSession();
    	int id=(Integer)session2.getAttribute("authorid");
    	String specialization=(String)session2.getAttribute("author_specialization");
        */
    	
    	UserModel um=new UserModel();
    	
    	HttpSession session2=request.getSession();
    	int id=(Integer)session2.getAttribute("authorid");
    	String special=um.getSpecialization(id);
        String Jtitle = request.getParameter("Jtitle");
        String Jkeywords = request.getParameter("Jkeywords");
        String Jdescription = request.getParameter("Jdescription");
        int eid=Integer.parseInt(request.getParameter("editor"));
        InputStream inputStream = null; // input stream of the upload file
         
        // obtains the upload file part in this multipart request
        Part filePart = request.getPart("Journal");
        if (filePart != null) {
            // prints out some information for debugging
            System.out.println(filePart.getName());
            System.out.println(filePart.getSize());
            System.out.println(filePart.getContentType());
             
            // obtains input stream of the upload file
            inputStream = filePart.getInputStream();
        }
         
        Connection conn = null; // connection to the database
        String message = null;  // message will be sent back to client
         
        try {
            // connects to the database
            Class.forName("oracle.jdbc.driver.OracleDriver");
            
            conn = DriverManager.getConnection(dbURL, dbUser, dbPass);
 
            // constructs SQL statement
            String sql = "INSERT INTO database values (journalid.nextval,?, ?, ?,?,?,?,'pending',?,'unread')";
            PreparedStatement statement = conn.prepareStatement(sql);
            statement.setString(1, Jtitle);
            statement.setString(2, Jkeywords);
            statement.setString(3,Jdescription);
             
            if (inputStream != null) {
                // fetches input stream of the upload file for the blob column
                //statement.setBlob(3, inputStream,30000);
                statement.setBinaryStream(4,inputStream,300000000);
            }
            statement.setInt(5,id);
            statement.setString(6,special);
            statement.setInt(7,eid);
 
            // sends the statement to the database server
            int row = statement.executeUpdate();
            if (row > 0) {
                out.println("<center><h3>File uploaded and saved into database<h3></center>");
                RequestDispatcher rd=request.getRequestDispatcher("addjournals.jsp");
                rd.include(request, response);
            }
        } catch (SQLException ex) {
            out.println("<center><h3>ERROR: " + ex.getMessage()+"</h3></center>");
            ex.printStackTrace();
        } catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
            if (conn != null) {
                // closes the database connection
                try {
                    conn.close();
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
            // sets the message in request scope
            //request.setAttribute("Message", message);
             
            // forwards to the message page
            //getServletContext().getRequestDispatcher("/Message.jsp").forward(request, response);
        }
    }
}