package LoginServlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import util.ConnectionProvider;

@WebServlet("/ContactUs")
public class ContactUs extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		String name= request.getParameter("Cname");
		String email=request.getParameter("CEmail");
		String message=request.getParameter("Cmessage");
		
		try{
			Connection conn=ConnectionProvider.getConn();
			PreparedStatement ps =conn.prepareStatement("insert into contact values(?,?,?)");
			ps.setString(1,name);
			ps.setString(2,email);
			ps.setString(3,message);
			int i=ps.executeUpdate();
			if(i==0){
				out.println("Message Submission Failed!!!");
			}
			else{
				out.println("Thanks For Contacting Us ");
			
		}
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}

}
