package LoginServlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Models.JouralModel;
import util.ConnectionProvider;

@WebServlet("/FetchPublihedJournals")
public class FetchPublihedJournals extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		JouralModel jm2 = new JouralModel();
		ArrayList<JouralModel> Publishlist = jm2.getPublishedJournals();
		HttpSession session=request.getSession();
		session.setAttribute("PublishedJDetails", Publishlist);
		response.sendRedirect("PublishedJournals.jsp");
		
		
	}

}
