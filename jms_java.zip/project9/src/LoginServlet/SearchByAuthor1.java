package LoginServlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Models.JouralModel;
@WebServlet("/SearchByAuthor1")
public class SearchByAuthor1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		int id=Integer.parseInt(request.getParameter("searchid"));
		System.out.println("ID TO BE SEARCHED :"+id);
		
		JouralModel jm7=new JouralModel();
		ArrayList<JouralModel> searchbyid=jm7.getJournalsById(id);
		System.out.println("AUTHOR JOURNALS BY ID:"+searchbyid);
		HttpSession session=request.getSession();
		session.setAttribute("JournalsById",searchbyid);
		//response.sendRedirect("SearchByAuthorResults.jsp");
		
		
		if(searchbyid.size()==0){
			
			
			RequestDispatcher rd1=request.getRequestDispatcher("SearchbyAuthor.jsp");
			rd1.include(request,response);
			out.println("<br/><br/><center>No Result Found</center>");
		}
		else{
		
		RequestDispatcher rd=request.getRequestDispatcher("SearchByAuthorResults.jsp");
		rd.forward(request,response);
		}
	
	}

}
