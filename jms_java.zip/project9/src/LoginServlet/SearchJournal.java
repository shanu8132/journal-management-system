package LoginServlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Models.JouralModel;

@WebServlet("/SearchJournal")
public class SearchJournal extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		String keyword=request.getParameter("keyword");
		System.out.println("Entered Keyword: "+keyword);
		JouralModel jm5=new JouralModel();
		ArrayList<JouralModel> searchlist= jm5.getSearchedJournals(keyword);
		HttpSession session=request.getSession();
		session.setAttribute("SearchList",searchlist);
		//response.sendRedirect("SearchResultJournal.jsp");
		if(searchlist.size()==0){
			RequestDispatcher rd= request.getRequestDispatcher("SearchJournal.jsp");
			rd.include(request,response);
			out.println("<br/><br/><center>No Result Found</center>");
		}
		
		else{
			RequestDispatcher rd=request.getRequestDispatcher("SearchResultJournal.jsp");
			rd.forward(request,response);
		}
	}

}
