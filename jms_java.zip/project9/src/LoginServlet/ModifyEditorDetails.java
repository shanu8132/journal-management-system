package LoginServlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import util.ConnectionProvider;

@WebServlet("/ModifyEditorDetails")
public class ModifyEditorDetails extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		int editorid=Integer.parseInt(request.getParameter("eid"));
		System.out.println("Author ID "+editorid);
		String firstname,lastname,email,password,dob,specialization,gender;
		
		firstname=request.getParameter("Efname");
		lastname=request.getParameter("Elname");
		email=request.getParameter("Eemail");
		password=request.getParameter("Epassword");
		dob=request.getParameter("Edob");
		specialization=request.getParameter("Especialization");
		gender=request.getParameter("Egender");
		try{
			Connection conn=ConnectionProvider.getConn();
			PreparedStatement ps=conn.prepareStatement("update editor set firstname=?,lastname=?,email=?,password=?,dob=?,specialization=?,gender=? where editorid=?");
			
			ps.setString(1,firstname);
			ps.setString(2,lastname);
			ps.setString(3,email);
			ps.setString(4,password);
			ps.setString(5,dob);
			ps.setString(6,specialization);
			ps.setString(7,gender);
			ps.setInt(8,editorid);
			int i=ps.executeUpdate();
			if(i==0){
				out.println("Editor Details Updation Failed!!!!");
				RequestDispatcher rd = request.getRequestDispatcher("ModifyEditors.jsp");
				rd.include(request, response);
			}
			else{
				out.println("Editor Details Updation Succesfull");
				RequestDispatcher rd = request.getRequestDispatcher("ModifyEditors.jsp");
				rd.include(request, response);
			}
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}

}
