package LoginServlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import javax.servlet.http.HttpSession;

import Models.EditorModel;


@WebServlet("/ELoginController")
public class ELoginController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		String user = request.getParameter("Eusername");
		String pass = request.getParameter("Epassword");
		
		System.out.println(user+" "+pass);
		
		EditorModel obj = new EditorModel();
		obj.setEmail(user);
		obj.setUpass(pass);
		
		int result = obj.validate();
		if(result!=0){
			HttpSession session = request.getSession();
			session.setAttribute("uname", user);
			response.sendRedirect("EWelcome.jsp");
			session.setAttribute("EditorId",result);
		}
		else{
			out.println("Username or password not correct");
			RequestDispatcher rd = request.getRequestDispatcher("ELogin.jsp");
			rd.include(request, response);
		}
	}

}


