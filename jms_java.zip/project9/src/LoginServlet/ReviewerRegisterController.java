package LoginServlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Models.ReviewerModel;



@WebServlet("/ReviewerRegisterController")
public class ReviewerRegisterController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		String user = request.getParameter("REmail");
		String pass = request.getParameter("Rpass");
		String fname = request.getParameter("Rname");
		String lname = request.getParameter("Rlname");
		String dob=request.getParameter("Rdob");
		String gender=request.getParameter("RGender");
	
		ReviewerModel obj = new ReviewerModel();
		obj.setUname(user);
		obj.setUpass(pass);
		obj.setFname(fname);
		obj.setLname(lname);
		obj.setEmail(user);
		obj.setGender(gender);
		obj.setDob(dob);
		
		String result = obj.register();
		if(result.equals("success"))
		{
			out.println("<center><h3 style='color:red'>Registered Successfully .... <a href='RLogin.jsp'>click here for Login</a></h3></center>");
			RequestDispatcher rd = request.getRequestDispatcher("RRegister.jsp");
			rd.include(request, response);
		
		}
		else{
			out.println("Registration Failed please Try Again");
			RequestDispatcher rd = request.getRequestDispatcher("RRegister.jsp");
			rd.include(request, response);
		}
		}
	}



