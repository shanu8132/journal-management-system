package LoginServlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import util.ConnectionProvider;
import Models.JournalReviewModel;
@WebServlet("/ReviewJournal")
public class ReviewJournal extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		HttpSession session = request.getSession();
		int eid=(Integer)session.getAttribute("EditorId");
		int aid=Integer.parseInt(request.getParameter("authorid"));
				
				
		
		int id=Integer.parseInt(request.getParameter("fid"));
		System.out.println("journal id " + id);
		System.out.println("Author id " + aid);
		
		
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		String range=request.getParameter("MatchingRange");
		String content=request.getParameter("PaperContent");
		String addedvalue=request.getParameter("AddedValue");
		String pubprev=request.getParameter("ResPub");
		String papervol=request.getParameter("PaperVolume");
		String imp=request.getParameter("Importance");
		String rtype=request.getParameter("ResearchType");
		String result=request.getParameter("Result");
	
	
		JournalReviewModel jrm=new JournalReviewModel();
		jrm.setRange(range);
		jrm.setContent(content);
		jrm.setAddedvalue(addedvalue);
		jrm.setPubprev(pubprev);
		jrm.setPapervol(papervol);
		jrm.setImp(imp);
		jrm.setRtype(rtype);
		jrm.setResult(result);
		jrm.setJid(id);
		jrm.setAid(aid);
		jrm.setEid(eid);
		
		String result1 =jrm.addreview();
		System.out.println(result1);
		if(result1.equals("success")){
			try{
				Connection conn=ConnectionProvider.getConn();
				PreparedStatement ps=conn.prepareStatement("update database set status='reviewed' where id=?");
				ps.setInt(1,id);
				int i=ps.executeUpdate();
				if(i==0){
					System.out.println("Status Changing Failed!!!");
				}
				else{
					System.out.println("Status Changed SUCCESSFULLY");
				}
			}
			catch(Exception e){
				e.printStackTrace();
			}
			out.println("<center><h2>Review Saved Successfully .... </h2></center>");
			RequestDispatcher rd=request.getRequestDispatcher("ReviewJournal.jsp");
			rd.include(request,response);
		
		}
		
		else{
			out.println("<center><h2>Review Process Failed.... please Try Again</h2></center>");
			RequestDispatcher rd=request.getRequestDispatcher("ReviewJournal.jsp");
			rd.include(request,response);
		}
	
		
	
	}

}
