package LoginServlet;


import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Models.ReviewerModel;



@WebServlet("/RLoginController")
public class RLoginController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		String user = request.getParameter("Rusername");
		String pass = request.getParameter("Rpassword");
		
		System.out.println(user+" "+pass);
		
		ReviewerModel obj = new ReviewerModel();
		obj.setEmail(user);
		obj.setUpass(pass);
		
		int ii = obj.validate();
		if(ii!=0){
			System.out.println("Reviewer Id "+ii);
			HttpSession session = request.getSession();
			session.setAttribute("uname", user);
			session.setAttribute("reviewerid", ii);
			response.sendRedirect("RWelcome.jsp");
		}
		else{
			out.println("Username or password not correct");
			RequestDispatcher rd = request.getRequestDispatcher("RLogin.jsp");
			rd.include(request, response);
		}
	}

}

