package LoginServlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import util.ConnectionProvider;

@WebServlet("/ModifyJDetails")
public class ModifyJDetails extends HttpServlet {
	private static final long serialVersionUID = 1L;
	int id;
	String title,description,keywords;
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");	
		PrintWriter out=response.getWriter();
		/*int id;
		String title,description,keywords;
		
		HttpSession session=request.getSession();
		id=Integer.parseInt(request.getParameter("jiid"));
		try {
			Connection conn=ConnectionProvider.getConn();
			PreparedStatement ps=conn.prepareStatement("select title,keywords,description from database where id=?");
			ps.setInt(1,id);
			ResultSet rs=ps.executeQuery();
			if(rs.next()) {
				title=rs.getString(1);
				keywords=rs.getString(2);
				description=rs.getString(3);
				
				request.setAttribute("title", title);
				request.setAttribute("keywords",keywords);
				request.setAttribute("description",description);

				RequestDispatcher rd=request.getRequestDispatcher("ModifyDetails.jsp");
				
				rd.forward(request,response);}
		
	}
		catch(Exception e){
			e.printStackTrace();
		}
	}

}*/
		title=request.getParameter("Jtitle");
		description=request.getParameter("Jdescription");
		keywords=request.getParameter("Jkeywords");
		HttpSession session=request.getSession();
		id=Integer.parseInt(request.getParameter("jiid"));
		System.out.println("title "+title);
		System.out.println("description "+description);
		System.out.println("keywords "+keywords);
		System.out.println("id "+ id);
		try{
			Connection conn=ConnectionProvider.getConn();
			PreparedStatement ps=conn.prepareStatement("update database set title=?,keywords=?,description=? where id=?");
			ps.setString(1,title);
			ps.setString(2,keywords);
			ps.setString(3,description);
			ps.setInt(4,id);
			int i=ps.executeUpdate();
			if(i==0){
				out.println("<center><h2>PROBLEM IN UPDATING RECORD</h2></center>");
				RequestDispatcher rd=request.getRequestDispatcher("ModifyDetails.jsp");
				rd.include(request,response);
				
			}
			else{
				out.println("<center><h2>RECORD UPDATION SUCCESFUL</h2></center>");
				RequestDispatcher rd=request.getRequestDispatcher("ModifyDetails.jsp");
				rd.include(request,response);
			}
		}
		catch(Exception e){
			e.printStackTrace();
		}
		}
	}
		
