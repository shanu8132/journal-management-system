package LoginServlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import util.ConnectionProvider;

@WebServlet("/ChangeNStatus")
public class ChangeNStatus extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		int id=Integer.parseInt(request.getParameter("reportid"));
		System.out.println("Journal id "+id);
		try{
			Connection conn=ConnectionProvider.getConn();
			PreparedStatement ps=conn.prepareStatement("update database set nstatus='read' where id=?");
			ps.setInt(1,id);
			int i=ps.executeUpdate();
			if(i==0){
				out.println("<center><h2>mark as unread failed!!!</h2></center>");
				RequestDispatcher rd=request.getRequestDispatcher("AunreadNotify.jsp");
				rd.include(request,response);
				}
			
			else if(i!=0){
				out.println("<center><h2>mark as unread Succesfull</h2></center>");
				RequestDispatcher rd=request.getRequestDispatcher("AunreadNotify.jsp");
				rd.include(request,response);
				
			}
			
		}
		catch(Exception e){
			e.printStackTrace();
		}
	
	
	}

}
