package LoginServlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import util.ConnectionProvider;

@WebServlet("/editprofile")
public class EditProfile extends HttpServlet {
	private static final long serialVersionUID = 1L;
	int id;
	String firstname,lastname,email,password,d,s,g;

	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");	
		PrintWriter out=response.getWriter();
		
		String action=request.getParameter("action");
		System.out.println("before edit profile connection");
		HttpSession session=request.getSession();
		String uname=(String)session.getAttribute("uname");
		try {
			Connection conn=ConnectionProvider.getConn();
			//DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","12345");
			PreparedStatement ps=conn.prepareStatement("select * from author where email=?");
			ps.setString(1,uname);
			ResultSet rs=ps.executeQuery();
			if(rs.next()) {
				id=rs.getInt(1);
				firstname=rs.getString(2);
				lastname=rs.getString(3);
				email=rs.getString(4);
				password=rs.getString(5);
				d=rs.getString(6);
				s=rs.getString(7);
				g=rs.getString(8);
				
				request.setAttribute("authorid", id);
				request.setAttribute("firstname",firstname);
				request.setAttribute("lastname",lastname);
				request.setAttribute("email",email);
				request.setAttribute("password",password);
				request.setAttribute("dob",d);
				request.setAttribute("specialization",s);
				request.setAttribute("gender",g);
				
				if(action.equals("Edit")){
				RequestDispatcher rd=request.getRequestDispatcher("editprofile.jsp");
				
				rd.forward(request,response);}
				
				if(action.equals("View")){
					RequestDispatcher rd=request.getRequestDispatcher("viewprofile.jsp");
					rd.forward(request,response);}
				
				
			}
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		HttpSession session2=request.getSession();
		System.out.println(id);
		session2.setAttribute("authorid", id);
		session2.setAttribute("author_specialization",s);
		response.sendRedirect("upload");
	}

}