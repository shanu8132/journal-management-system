package LoginServlet;
import Models.UserModel;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Models.UserModel;


@WebServlet("/changepassword")
public class ChangePasswordController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		HttpSession session=request.getSession();
		int id=(Integer)session.getAttribute("authorid");
		String newpass = request.getParameter("new");
		String confirm = request.getParameter("confirm");
		
		if(newpass.equals(confirm)){
			
	//HttpSession session2 = request.getSession();
	//String uname=(String)session.getAttribute("uname");
	
	UserModel obj = new UserModel();
	obj.setUpass(newpass);
	//obj.setUname(uname);
	
			
			String result = obj.changepass(id);
			if(result.equals("success")){
		out.println("<center><h4>Password Changed Successfully</h4></center>");
RequestDispatcher rd = request.getRequestDispatcher("changepass.jsp");
				rd.include(request, response);
			}
			else{
				out.println("Failed to change password");
				RequestDispatcher rd = request.getRequestDispatcher("changepass.jsp");
				rd.include(request, response);
			}

			
		}else{
		out.println("New Password & Confirm New Password must be same..");
		RequestDispatcher rd=request.getRequestDispatcher("changepass.jsp");
		rd.include(request,response);
		}
		
		
				
	}

}
