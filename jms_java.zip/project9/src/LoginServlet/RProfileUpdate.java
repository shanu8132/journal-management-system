package LoginServlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import util.ConnectionProvider;

@WebServlet("/RProfileUpdate")
public class RProfileUpdate extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		HttpSession session=request.getSession();
		
		int id= (Integer)session.getAttribute("reviewerid");
		String fname=request.getParameter("Rfname");
		String lname=request.getParameter("Rlname");
		String email=request.getParameter("Remail");
		String pass=request.getParameter("Rpass");
		String dob=request.getParameter("Rdob");
		String gender=request.getParameter("Rgender");
		//int id=Integer.parseInt(request.getParameter("authorid"));
		System.out.println("Reviewer id "+id);
		try{
			Connection conn=ConnectionProvider.getConn();
			PreparedStatement ps=conn.prepareStatement("update reviewer set firstname=?, lastname=?, email=?, password=?, dob=?, gender=? where reviewerid=?");
			ps.setString(1,fname);
			ps.setString(2,lname);
			ps.setString(3,email);
			ps.setString(4,pass);
			ps.setString(5,dob);
			ps.setString(6,gender);
			ps.setInt(7,id);
			int i=ps.executeUpdate();
			if(i==0){
				out.println("<center><h3>Profile Updation Failed!!!</h3></center>");
				RequestDispatcher rd=request.getRequestDispatcher("RViewProfile.jsp");
				rd.include(request, response);
			}
			else{
				out.println("<center><h3>Profile Updated Succesfully!!!</h3></center>");
				RequestDispatcher rd=request.getRequestDispatcher("RViewProfile.jsp");
				rd.include(request, response);
			}
		}
		
		catch(Exception e){
			e.printStackTrace();
		}
	

}}
