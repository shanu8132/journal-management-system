package LoginServlet;


import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import util.ConnectionProvider;




@WebServlet("/AdminLoginController")
public class AdminLoginController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		String AdminUser = request.getParameter("UserAdmin");
		String AdminPass = request.getParameter("PassAdmin");
		
		System.out.println(AdminUser+" "+AdminPass);
		
		try{
			Connection conn=ConnectionProvider.getConn();
			PreparedStatement ps=conn.prepareStatement("select * from admin where username=? and password=?");
			ps.setString(1,AdminUser);
			ps.setString(2,AdminPass);
			ResultSet rs = ps.executeQuery();
			
			if(rs.next()){
				
				System.out.println("username password is correct");
				RequestDispatcher rd= request.getRequestDispatcher("WelcomeAdmin.jsp");
				rd.forward(request,response);
		}
		else{
			System.out.println("username password is incorrect");
			out.println("Username or password not correct");
			RequestDispatcher rd = request.getRequestDispatcher("AdminLogin.jsp");
			rd.include(request, response);
		}
	}
		catch(Exception e){
			e.printStackTrace();
		}

}
}

