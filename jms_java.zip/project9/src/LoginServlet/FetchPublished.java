package LoginServlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Models.JouralModel;
import util.ConnectionProvider;

@WebServlet("/FetchPublished")
public class FetchPublished extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session=request.getSession();
		int eid=(Integer)session.getAttribute("EditorId");
		System.out.println("EditorId "+eid);
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		JouralModel jm3 = new JouralModel();
		ArrayList<JouralModel> Publishlist = jm3.getPublishbyEditor(eid);
		
		session.setAttribute("PublishedJDetails", Publishlist);
		response.sendRedirect("published.jsp");
		
		
	}

}
