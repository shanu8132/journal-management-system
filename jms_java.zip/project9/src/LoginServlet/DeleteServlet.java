package LoginServlet;


import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import util.ConnectionProvider;

@WebServlet("/DeleteServlet")
public class DeleteServlet extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		int id=Integer.parseInt(request.getParameter("jiid"));
		System.out.println("Journal id"+ id);
		try{
			Connection conn=ConnectionProvider.getConn();
			PreparedStatement ps=conn.prepareStatement("delete from reviewjournal where id=?");
			ps.setInt(1,id);
			int i=ps.executeUpdate();
			if(i==0){
				out.println("<center><h2>Record Cannot be Deleted before the editor review it</h2></center> ");
				RequestDispatcher rd=request.getRequestDispatcher("ModifyJournal.jsp");
				rd.include(request, response);
			}
			else{
				try{
					PreparedStatement ps1=conn.prepareStatement("delete from database where id=?");
					ps1.setInt(1,id);
					int j=ps1.executeUpdate();
					if(j==0){
						out.println("<center><h2>Problem in Deleting in database table</h2></center>");
						RequestDispatcher rd=request.getRequestDispatcher("ModifyJournal.jsp");
						rd.include(request, response);
					}
					else{
						out.println("<center><h2>RECORD DELETED SUCESSFULLY....</h2></center>");
						RequestDispatcher rd=request.getRequestDispatcher("ModifyJournal.jsp");
						rd.include(request, response);
					}
				}
				catch(Exception e){
					e.printStackTrace();
				}
				
			}
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}


}
