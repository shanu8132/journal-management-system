package LoginServlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import util.ConnectionProvider;


@WebServlet("/EUnread")
public class EUnread extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		System.out.println("In EUnread Servlet");
		HttpSession session=request.getSession();
		int eid=(int)session.getAttribute("EditorId");
		
		System.out.println("editor id : "+eid);
		
		try{
			Connection conn=ConnectionProvider.getConn();
			PreparedStatement ps=conn.prepareStatement("select * from database where editorid=? and status='pending'");
			ps.setInt(1,eid);
			ResultSet rs=ps.executeQuery();
			while(rs.next()){
				System.out.println("I m in loop");
			}
		}
		catch(Exception e){
			
		}
	}

}
