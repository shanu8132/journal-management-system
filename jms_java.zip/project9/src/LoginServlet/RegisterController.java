package LoginServlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Models.UserModel;



@WebServlet("/RegisterController")
public class RegisterController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		String user = request.getParameter("AEmail");
		String pass = request.getParameter("Apass");
		String fname = request.getParameter("Aname");
		String lname = request.getParameter("Alname");
		String specialization=request.getParameter("SpecialisedField");
		String dob=request.getParameter("Adob");
		String gender=request.getParameter("GenderList");
	
		UserModel obj = new UserModel();
		obj.setUname(user);
		obj.setUpass(pass);
		obj.setFname(fname);
		obj.setLname(lname);
		obj.setEmail(user);
		obj.setSpecialization(specialization);
		obj.setGender(gender);
		obj.setDob(dob);
		
		String result = obj.register();
		if(result.equals("success"))
		{
			out.println("<center><h3 style='color:red'>Registered Successfully .... <a href='ALogin.jsp'>click here to Login</a></h4></center>");
			RequestDispatcher rd=request.getRequestDispatcher("ARegister.jsp");
			rd.include(request,response);
		}
		else{
			out.println("Registration Failed please Try Again");
			RequestDispatcher rd = request.getRequestDispatcher("ARegister.jsp");
			rd.include(request, response);
		}
		}
	}



