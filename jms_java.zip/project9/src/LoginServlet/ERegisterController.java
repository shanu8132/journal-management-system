package LoginServlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Models.EditorModel;
import Models.UserModel;



@WebServlet("/ERegisterController")
public class ERegisterController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		String user = request.getParameter("EEmail");
		String pass = request.getParameter("Epass");
		String fname = request.getParameter("Ename");
		String lname = request.getParameter("Elname");
		String specialization=request.getParameter("SpecialisedField");
		String dob=request.getParameter("Edob");
		String gender=request.getParameter("EGender");
	
		EditorModel obj = new EditorModel();
		obj.setUname(user);
		obj.setUpass(pass);
		obj.setFname(fname);
		obj.setLname(lname);
		obj.setEmail(user);
		obj.setSpecialization(specialization);
		obj.setGender(gender);
		obj.setDob(dob);
		
		String result = obj.register();
		if(result.equals("success"))
		{
			out.println("<center><h3 style='color:red'>Registered Successfully .... <a href='ELogin.jsp'>click here for Login</a></h3></center>");
			RequestDispatcher rd=request.getRequestDispatcher("ERegister.jsp");
			rd.include(request,response);
		}
		else{
			out.println("<center><h3 style='color:red'>Registration Failed please Try Again</h3></center>");
			RequestDispatcher rd = request.getRequestDispatcher("ERegister.jsp");
			rd.include(request, response);
		}
		}
	}



