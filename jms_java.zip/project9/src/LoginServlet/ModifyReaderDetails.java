package LoginServlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import util.ConnectionProvider;

@WebServlet("/ModifyReaderDetails")
public class ModifyReaderDetails extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		int reviewerid=Integer.parseInt(request.getParameter("rid"));
		System.out.println("Author ID "+reviewerid);
		String firstname,lastname,email,password,dob,gender;
		
		firstname=request.getParameter("Rfname");
		lastname=request.getParameter("Rlname");
		email=request.getParameter("Remail");
		password=request.getParameter("Rpassword");
		dob=request.getParameter("Rdob");
		gender=request.getParameter("Rgender");
		try{
			Connection conn=ConnectionProvider.getConn();
			PreparedStatement ps=conn.prepareStatement("update reviewer set firstname=?,lastname=?,email=?,password=?,dob=?,gender=? where reviewerid=?");
			
			ps.setString(1,firstname);
			ps.setString(2,lastname);
			ps.setString(3,email);
			ps.setString(4,password);
			ps.setString(5,dob);
			ps.setString(6,gender);
			ps.setInt(7,reviewerid);
			int i=ps.executeUpdate();
			if(i==0){
				out.println("Reviewer Details Updation Failed!!!!");
				RequestDispatcher rd = request.getRequestDispatcher("ModifyReader.jsp");
				rd.include(request, response);
			}
			else{
				out.println("Reviewer Details Updation Succesfull");
				RequestDispatcher rd = request.getRequestDispatcher("ModifyReader.jsp");
				rd.include(request, response);
			}
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}

}
