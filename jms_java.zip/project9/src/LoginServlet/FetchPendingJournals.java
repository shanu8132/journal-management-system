package LoginServlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Models.JouralModel;

@WebServlet("/FetchPendingJournals")
public class FetchPendingJournals extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		JouralModel jm1 = new JouralModel();
		ArrayList<JouralModel> Plist = jm1.getPendingJournalDetails();
		HttpSession session=request.getSession();
		session.setAttribute("PJDetails", Plist);
		
		response.sendRedirect("PendingJournals.jsp");
		
		
	}

}
