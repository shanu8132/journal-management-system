package LoginServlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import util.ConnectionProvider;

@WebServlet("/ModifyAuthorDetails")
public class ModifyAuthorDetails extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		int authorid=Integer.parseInt(request.getParameter("aid"));
		System.out.println("Author ID "+authorid);
		String firstname,lastname,email,password,dob,specialization,gender;
		
		firstname=request.getParameter("Afname");
		lastname=request.getParameter("Alname");
		email=request.getParameter("Aemail");
		password=request.getParameter("Apassword");
		dob=request.getParameter("Adob");
		specialization=request.getParameter("Aspecialization");
		gender=request.getParameter("Agender");
		try{
			Connection conn=ConnectionProvider.getConn();
			PreparedStatement ps=conn.prepareStatement("update author set firstname=?,lastname=?,email=?,password=?,dob=?,specialization=?,gender=? where authorid=?");
			
			ps.setString(1,firstname);
			ps.setString(2,lastname);
			ps.setString(3,email);
			ps.setString(4,password);
			ps.setString(5,dob);
			ps.setString(6,specialization);
			ps.setString(7,gender);
			ps.setInt(8,authorid);
			int i=ps.executeUpdate();
			if(i==0){
				out.println("Author Details Updation Failed!!!!");
				RequestDispatcher rd = request.getRequestDispatcher("ModifyAuthors.jsp");
				rd.include(request, response);
			}
			else{
				out.println("Author Details Updation Succesfull");
				RequestDispatcher rd = request.getRequestDispatcher("ModifyAuthors.jsp");
				rd.include(request, response);
			}
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}

}
