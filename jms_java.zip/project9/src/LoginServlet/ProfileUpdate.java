package LoginServlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import util.ConnectionProvider;

@WebServlet("/ProfileUpdate")
public class ProfileUpdate extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		HttpSession session=request.getSession();
		int id= (Integer)session.getAttribute("authorid");
		String fname=request.getParameter("fname");
		String lname=request.getParameter("lname");
		String email=request.getParameter("email");
		String dob=request.getParameter("dob");
		String gender=request.getParameter("GenderList");
		//int id=Integer.parseInt(request.getParameter("authorid"));
		System.out.println("Author id "+id);
		try{
			Connection conn=ConnectionProvider.getConn();
			PreparedStatement ps=conn.prepareStatement("update author set firstname=?, lastname=?, email=?, dob=?, gender=? where authorid=?");
			ps.setString(1,fname);
			ps.setString(2,lname);
			ps.setString(3,email);
			ps.setString(4,dob);
			ps.setString(5,gender);
			ps.setInt(6,id);
			int i=ps.executeUpdate();
			if(i==0){
				out.println("<center><h3>Profile Updation Failed!!!</h3></center>");
				RequestDispatcher rd=request.getRequestDispatcher("editprofile.jsp");
				rd.include(request, response);
			}
			else{
				out.println("<center><h3>Profile Updated Succesfully!!!</h3></center>");
				RequestDispatcher rd=request.getRequestDispatcher("editprofile.jsp");
				rd.include(request, response);
			}
		}
		
		catch(Exception e){
			e.printStackTrace();
		}
	

}}
