package LoginServlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Models.EditorModel;
import Models.UserModel;

@WebServlet("/FetchEditor")
public class FetchEditor extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		
		
		HttpSession session=request.getSession();
		int authorid=(int)session.getAttribute("authorid");
		System.out.println("Author Id in Fetch : "+authorid);
		
		UserModel um=new UserModel();
		String authSpec=um.getSpecialization(authorid);
		
		System.out.println("Author Specialization : "+authSpec);
		
		EditorModel em=new EditorModel();
		List<EditorModel> editorList=em.getEditorDetails(authSpec);
		session.setAttribute("editorList",editorList);
		
		response.sendRedirect("addjournals.jsp");
				
		
		
		
		
		
		
		
	}

}
