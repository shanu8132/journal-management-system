package LoginServlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Models.JouralModel;
import Models.ReportModel;
import util.ConnectionProvider;

@WebServlet("/ViewReport")
public class ViewReport extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	
	
	
	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		int rid=Integer.parseInt(request.getParameter("reportid"));
		
	
		ReportModel rm=new ReportModel();
		ArrayList<ReportModel> report=rm.getReport(rid);
		HttpSession session=request.getSession();
		session.setAttribute("reportDetail",report);
		
		response.sendRedirect("ViewReport.jsp");
		
		
		
		
			}
		
	

	}
