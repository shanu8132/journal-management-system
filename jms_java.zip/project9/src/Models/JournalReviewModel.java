package Models;

import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.servlet.http.HttpSession;
import javax.websocket.Session;

import util.ConnectionProvider;

public class JournalReviewModel {
	private String range;
	private String content;
	private String addedvalue;
	private String pubprev;
	private String papervol;
	private String imp;
	private String rtype;
	private String result;
	private int jid;
	private int eid;
	private int aid;
    
	
		
	public String getRange() {
		return range;
	}
	public void setRange(String range) {
		this.range = range;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getAddedvalue() {
		return addedvalue;
	}
	public void setAddedvalue(String addedvalue) {
		this.addedvalue = addedvalue;
	}
	public String getPubprev() {
		return pubprev;
	}
	public void setPubprev(String pubprev) {
		this.pubprev = pubprev;
	}
	public String getPapervol() {
		return papervol;
	}
	public void setPapervol(String papervol) {
		this.papervol = papervol;
	}
	public String getImp() {
		return imp;
	}
	public void setImp(String imp) {
		this.imp = imp;
	}
	public String getRtype() {
		return rtype;
	}
	public void setRtype(String rtype) {
		this.rtype = rtype;
	}
	public String getResult() {
		return result;
	}
	public int getJid() {
		return jid;
	}
	public void setJid(int jid) {
		this.jid = jid;
	}
	public int getEid() {
		return eid;
	}
	public void setEid(int eid) {
		this.eid = eid;
	}
	public int getAid() {
		return aid;
	}
	public void setAid(int aid) {
		this.aid = aid;
	}
	public void setResult(String result) {
		this.result = result;
	}
	
	
	String n;
	public String addreview(){
		try {
			
			System.out.println("I m here");
			Connection conn=ConnectionProvider.getConn();
			
			PreparedStatement ps = conn.prepareStatement("insert into reviewjournal values(?,?,?,?,?,?,?,?,?,?,?)");
			ps.setString(1,getRange());
			ps.setString(2, getContent());
			ps.setString(3, getAddedvalue());
			ps.setString(4,getPubprev());
			ps.setString(5,getPapervol());
			ps.setString(6,getImp());
			ps.setString(7,getRtype());
			ps.setString(8,getResult());
			ps.setInt(9,getJid());
			ps.setInt(10,getAid());
			ps.setInt(11,getEid());
			int i = ps.executeUpdate();
				if(i==0){
					n="failed";
				}
				else{
					n="success";
						
				}
		} catch (Exception e) {
			
			e.printStackTrace();
		}
		return n;
	}
	
}
