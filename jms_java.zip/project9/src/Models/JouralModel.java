package Models;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import LoginServlet.ViewReport;
import util.ConnectionProvider;

public class JouralModel implements Serializable {
		int id;
		String title;
		String keywords;
		String description;
		String specialization;
		String status;
		int editorid;
		int authorid;
		public int getId() {
			return id;
		}
		public void setId(int id) {
			this.id = id;
		}
		public String getTitle() {
			return title;
		}
		public void setTitle(String title) {
			this.title = title;
		}
		public String getKeywords() {
			return keywords;
		}
		public void setKeywords(String keywords) {
			this.keywords = keywords;
		}
		public String getDescription() {
			return description;
		}
		public void setDescription(String description) {
			this.description = description;
		}
		public String getSpecialization() {
			return specialization;
		}
		public void setSpecialization(String specialization) {
			this.specialization = specialization;
		}
		public String getStatus() {
			return status;
		}
		public void setStatus(String status) {
			this.status = status;
		}
		public int getEditorid() {
			return editorid;
		}
		public void setEditorid(int editorid) {
			this.editorid = editorid;
		}
		public int getAuthorid() {
			return authorid;
		}
		public void setAuthorid(int authorid) {
			this.authorid = authorid;
		}
		private String authorName;
		private String editorName;
		
		
		
		
		public String getAuthorName() {
			return authorName;
		}
		public void setAuthorName(String authorName) {
			this.authorName = authorName;
		}
		public String getEditorName() {
			return editorName;
		}
		public void setEditorName(String editorName) {
			this.editorName = editorName;
		}
		ArrayList<JouralModel> list = new ArrayList<>();
		public ArrayList<JouralModel> getJournalDetails(){
			try{
				Connection conn=ConnectionProvider.getConn();
				PreparedStatement ps=conn.prepareStatement("Select id,title,keywords,description,authorid,specialization,status,editorid from database");
				ResultSet rs=ps.executeQuery();
				while(rs.next()){
					JouralModel jm=new JouralModel();
					jm.id=rs.getInt(1);
					jm.title=rs.getString(2);
					jm.keywords=rs.getString(3);
					jm.description=rs.getString(4);
					jm.authorid=rs.getInt(5);
					jm.specialization=rs.getString(6);
					jm.status=rs.getString(7);
					jm.editorid=rs.getInt(8);
					
					jm.editorName=new EditorModel().getEditorName(jm.editorid);
					jm.authorName=new UserModel().getAuthorName(jm.authorid);
					System.out.println(jm.editorName);
					
					list.add(jm);
				
				
					
				}
				
			}
			catch(Exception e){
				e.printStackTrace();
			}
			return list;
		}
		
		ArrayList<JouralModel> Plist = new ArrayList<>();
		public ArrayList<JouralModel> getPendingJournalDetails(){
			try{
				Connection conn=ConnectionProvider.getConn();
				PreparedStatement ps=conn.prepareStatement("select id,title,keywords,description,authorid,specialization,editorid from database where status='pending'");
				ResultSet rs=ps.executeQuery();
				
				while(rs.next()){
					JouralModel jm1=new JouralModel();
					jm1.id=rs.getInt(1);
					jm1.title=rs.getString(2);
					jm1.keywords=rs.getString(3);
					jm1.description=rs.getString(4);
					jm1.authorid=rs.getInt(5);
					jm1.specialization=rs.getString(6);
					jm1.editorid=rs.getInt(7);
					
					jm1.editorName=new EditorModel().getEditorName(jm1.editorid);
					jm1.authorName=new UserModel().getAuthorName(jm1.authorid);
					System.out.println(jm1.editorName);
					
					Plist.add(jm1);
				
				
					
				}
				
			}
			catch(Exception e){
				e.printStackTrace();
			}
			return Plist;
		}
		int publishedid;
		ArrayList<JouralModel> Publishlist = new ArrayList<>();
		public ArrayList<JouralModel> getPublishedJournals(){
			try{
				Connection conn=ConnectionProvider.getConn();
				PreparedStatement ps=conn.prepareStatement("select id from reviewjournal where (result='Accepter for publishing with editing' OR result='Accepter for publishing without editing')");
				ResultSet rs=ps.executeQuery();
				while(rs.next()){
					publishedid=rs.getInt(1);
					
					try{
						Connection conn1=ConnectionProvider.getConn();
						PreparedStatement ps1=conn1.prepareStatement("select id,title,keywords,description,authorid,specialization,editorid from database where id=?");
						ps1.setInt(1,publishedid);
						ResultSet rs1=ps1.executeQuery();
						while(rs1.next()){
						JouralModel jm2=new JouralModel();
						jm2.id=rs1.getInt(1);
						jm2.title=rs1.getString(2);
						jm2.keywords=rs1.getString(3);
						jm2.description=rs1.getString(4);
						jm2.authorid=rs1.getInt(5);
						jm2.specialization=rs1.getString(6);
						jm2.editorid=rs1.getInt(7);
						
						jm2.editorName=new EditorModel().getEditorName(jm2.editorid);
						jm2.authorName=new UserModel().getAuthorName(jm2.authorid);
						System.out.println(jm2.editorName);
						System.out.println(jm2.authorName);
						System.out.println(jm2.id);
						System.out.println(jm2.title);
						System.out.println(jm2.keywords);
						System.out.println(jm2.description);
						System.out.println(jm2.authorid);
						System.out.println(jm2.specialization);
						System.out.println(jm2.editorid);
						Publishlist.add(jm2);
				
					}
					}
					catch(Exception e){
						e.printStackTrace();
					}
						
				}	
			}
			catch(Exception e){
				e.printStackTrace();
			}
			return Publishlist;
		
}
		int jid;
		ArrayList<JouralModel> PublishbyEditor=new ArrayList<>(); 
		public ArrayList<JouralModel> getPublishbyEditor(int idd){
			try{
				Connection conn=ConnectionProvider.getConn();
				PreparedStatement ps=conn.prepareStatement("select id from reviewjournal where ((result='Accepter for publishing with editing' OR result='Accepter for publishing without editing') AND editorid=?)");
				ps.setInt(1,idd);
				ResultSet rs=ps.executeQuery();	
				while(rs.next()){
					
				
					jid=rs.getInt(1);
					try{
						Connection conn2=ConnectionProvider.getConn();
						PreparedStatement ps2=conn2.prepareStatement("select id,title,keywords,description,authorid,specialization,editorid from database where id=?");
						ps2.setInt(1,jid);
						ResultSet rs2=ps2.executeQuery();
						while(rs2.next()){
							
						JouralModel jm3=new JouralModel();
						jm3.id=rs2.getInt(1);
						jm3.title=rs2.getString(2);
						jm3.keywords=rs2.getString(2);
						jm3.description=rs2.getString(4);
						jm3.authorid=rs2.getInt(5);
						jm3.specialization=rs2.getString(6);
						jm3.editorid=rs2.getInt(7);
						
						jm3.editorName=new EditorModel().getEditorName(jm3.editorid);
						jm3.authorName=new UserModel().getAuthorName(jm3.authorid);
						PublishbyEditor.add(jm3);
				
			}}
						catch(Exception e){
							e.printStackTrace();
						}
				}
			}
			catch(Exception e){
				e.printStackTrace();
			}
			return PublishbyEditor;
		}
		
		ArrayList<JouralModel> AllPJournals=new ArrayList<>(); 
		public ArrayList<JouralModel> getAllPJournals(){
			try{
				Connection conn=ConnectionProvider.getConn();
				PreparedStatement ps=conn.prepareStatement("select id from reviewjournal where (result='Accepter for publishing with editing' OR result='Accepter for publishing without editing')");
				ResultSet rs=ps.executeQuery();	
				while(rs.next()){
					
				
					jid=rs.getInt(1);
					try{
						Connection conn2=ConnectionProvider.getConn();
						PreparedStatement ps2=conn2.prepareStatement("select id,title,keywords,description,authorid,specialization,editorid from database where id=?");
						ps2.setInt(1,jid);
						ResultSet rs2=ps2.executeQuery();
						while(rs2.next()){
							
						JouralModel jm4=new JouralModel();
						jm4.id=rs2.getInt(1);
						jm4.title=rs2.getString(2);
						jm4.keywords=rs2.getString(2);
						jm4.description=rs2.getString(4);
						jm4.authorid=rs2.getInt(5);
						jm4.specialization=rs2.getString(6);
						jm4.editorid=rs2.getInt(7);
						
						jm4.editorName=new EditorModel().getEditorName(jm4.editorid);
						jm4.authorName=new UserModel().getAuthorName(jm4.authorid);
						AllPJournals.add(jm4);
				
			}}
						catch(Exception e){
							e.printStackTrace();
						}
				}
			}
			catch(Exception e){
				e.printStackTrace();
			}
			return AllPJournals;
		}
		String keywords2;
		int sid;
		ArrayList<JouralModel> searchlist=new ArrayList<>();
		public ArrayList<JouralModel> getSearchedJournals(String Skeyword){
			keywords2=(String)Skeyword;
			System.out.println("ENTERED KEYWORD IN MODEL :"+keywords2);
			try{
				Connection conn=ConnectionProvider.getConn();
				PreparedStatement ps=conn.prepareStatement("select id from reviewjournal where (result='Accepter for publishing with editing' OR result='Accepter for publishing without editing')");
				ResultSet rs=ps.executeQuery();
				while(rs.next()){
					sid=rs.getInt(1);
					System.out.println("ID OF PUBLISHED JOURNALS :"+sid);
					try{
						PreparedStatement ps1=conn.prepareStatement("select id,title,description,authorid,keywords from database where ((id=?) AND (keywords like '%"+keywords2+"%'))");
						ps1.setInt(1,sid);
						ResultSet rs1=ps1.executeQuery();
						while(rs1.next()){
							JouralModel jm5=new JouralModel();
							jm5.id=rs1.getInt(1);
							jm5.title=rs1.getString(2);
							jm5.description=rs1.getString(3);
							jm5.authorid=rs1.getInt(4);
							jm5.keywords=rs1.getString(5);
							System.out.println("Title "+jm5.title);
							searchlist.add(jm5);
							
						}
					}
					catch(Exception e){
						e.printStackTrace();
					}
				}
			}
			catch(Exception e){
				e.printStackTrace();
			}
			return searchlist;
		
		
		
		
		
		}
		
		
		ArrayList<JouralModel> allnotify=new ArrayList();
		public ArrayList<JouralModel> getAllNotify(int aid){
			try{
				Connection conn2=ConnectionProvider.getConn();
				PreparedStatement ps2=conn2.prepareStatement("select id,title,editorid from database where authorid=? AND (status='reviewed' AND (nstatus='read' OR nstatus='unread'))");
				ps2.setInt(1,aid);
				ResultSet rs2=ps2.executeQuery();
				while(rs2.next()){
					JouralModel jm6=new JouralModel();
					jm6.id=rs2.getInt(1);
					jm6.title=rs2.getString(2);
					jm6.editorid=rs2.getInt(3);
					jm6.editorName=new EditorModel().getEditorName(jm6.editorid);
					
					allnotify.add(jm6);
					
				}
			}
			catch(Exception e){
				e.printStackTrace();
			}
			return allnotify;
		}
		
		
		
		ArrayList<JouralModel> unreadnotify=new ArrayList();
		public ArrayList<JouralModel> getUnreadNotify(int aid){
			try{
				Connection conn2=ConnectionProvider.getConn();
				PreparedStatement ps2=conn2.prepareStatement("select id,title,editorid from database where authorid=? AND (nstatus='unread' AND status='reviewed') ");
				ps2.setInt(1,aid);
				ResultSet rs2=ps2.executeQuery();
				while(rs2.next()){
					JouralModel jm6=new JouralModel();
					jm6.id=rs2.getInt(1);
					jm6.title=rs2.getString(2);
					jm6.editorid=rs2.getInt(3);
					jm6.editorName=new EditorModel().getEditorName(jm6.editorid);
					
					unreadnotify.add(jm6);
					
				}
			}
			catch(Exception e){
				e.printStackTrace();
			}
			return unreadnotify;
		}
		
		int searchid;
		ArrayList<JouralModel> searchbyid=new ArrayList();
		public ArrayList<JouralModel> getJournalsById(int sid){
			try{
				Connection conn=ConnectionProvider.getConn();
				PreparedStatement ps7=conn.prepareStatement("select id from reviewjournal  where (authorid=? AND (result='Accepter for publishing without editing' OR result='Accepter for publishing with editing'))");
				ps7.setInt(1,sid);
				ResultSet rs7=ps7.executeQuery();
				while(rs7.next()){
					searchid=rs7.getInt(1);
					try{
						
					
					PreparedStatement ps8=conn.prepareStatement("select id,title,keywords from database where id=?");
					ps8.setInt(1,searchid);
					ResultSet rs8=ps8.executeQuery();
					while(rs8.next()){
					JouralModel jm7=new JouralModel();
					jm7.id=rs8.getInt(1);
					jm7.title=rs8.getString(2);
					jm7.keywords=rs8.getString(3);
					jm7.authorName=new UserModel().getAuthorName(sid);
					System.out.println("id :"+jm7.id);
					System.out.println("title :"+jm7.title);
					System.out.println("keywords :"+jm7.keywords);
					System.out.println("Author Name :"+jm7.authorName);
					
					searchbyid.add(jm7);
				}
			}
			catch(Exception e){
				e.printStackTrace();
				
			}
				
		}
		
}catch(Exception e){
	e.printStackTrace();
}
			System.out.println("Search By Id in Model : "+searchbyid);
			return searchbyid;
		}
		
		ArrayList<JouralModel> Eallnotify=new ArrayList();
		public ArrayList<JouralModel> getEAllNotify(int eid){
			try{
				Connection conn2=ConnectionProvider.getConn();
				PreparedStatement ps2=conn2.prepareStatement("select id,title,description,authorid from database where editorid=? AND ((status='pending' or status='reviewed') AND (nstatus='read' OR nstatus='unread'))");
				ps2.setInt(1,eid);
				ResultSet rs2=ps2.executeQuery();
				while(rs2.next()){
					JouralModel jm8=new JouralModel();
					jm8.id=rs2.getInt(1);
					jm8.title=rs2.getString(2);
					jm8.description=rs2.getString(3);
					jm8.authorid=rs2.getInt(4);
					jm8.authorName=new UserModel().getAuthorName(jm8.authorid);
					System.out.println("Author Name:"+ jm8.authorName);
					Eallnotify.add(jm8);
					
				}
			}
			catch(Exception e){
				e.printStackTrace();
			}
			return Eallnotify;
		}

		
		ArrayList<JouralModel> EunreadNotify=new ArrayList();
		public ArrayList<JouralModel> getEunreadNotify(int eid){
			try{
				Connection conn2=ConnectionProvider.getConn();
				PreparedStatement ps2=conn2.prepareStatement("select id,title,description,authorid from database where editorid=? AND (nstatus='unread' AND status='pending') ");
				ps2.setInt(1,eid);
				ResultSet rs2=ps2.executeQuery();
				while(rs2.next()){
					JouralModel jm9=new JouralModel();
					jm9.id=rs2.getInt(1);
					jm9.title=rs2.getString(2);
					jm9.description=rs2.getString(3);
					jm9.authorid=rs2.getInt(4);
					jm9.authorName=new UserModel().getAuthorName(jm9.authorid);
					System.out.println("Author Name:"+ jm9.authorName);
					EunreadNotify.add(jm9);
					
				}
			}
			catch(Exception e){
				e.printStackTrace();
			}
			return EunreadNotify;
		}

}