package Models;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import util.ConnectionProvider;

public class ReviewerModel {
	private String uname;
	private String upass;
	private String lname;
	private String fname;
	private String email;

	private String gender;
	private String dob;
	

	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}

	String tablename = "usertable";
	
	public String getUname() {
		return uname;
	}
	public void setUname(String uname) {
		this.uname = uname;
	}
	public String getUpass() {
		return upass;
	}
	public void setUpass(String upass) {
		this.upass = upass;
	}
	public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	
	int i;
	public int validate(){
		try {
			Connection conn = ConnectionProvider.getConn();
			PreparedStatement ps = conn.prepareStatement("select * from reviewer where Email=? and Password=?");
			ps.setString(1, email);
			ps.setString(2, upass);
			ResultSet rs = ps.executeQuery();
			if(rs.next()){
				i=rs.getInt(1);
				System.out.println("I m here in if");
			}
			else{
				System.out.println("I m here in else");
				i=0;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return i;
	}
	String m;
	public String register(){
		try {
			Connection conn=ConnectionProvider.getConn();
			
			PreparedStatement ps = conn.prepareStatement("insert into reviewer values(reviewerseq.nextval,?,?,?,?,?,?)");
			ps.setString(1, fname);
			ps.setString(2, lname);
			ps.setString(3, email);
			ps.setString(4,upass);
			ps.setString(5,dob);
			ps.setString(6,gender);
			
			int i = ps.executeUpdate();
				if(i==0){
					m="failed";
				}
				else{
					m="success";
						
				}
		} catch (Exception e) {
			
			e.printStackTrace();
		}
		return m;
	}

	}

