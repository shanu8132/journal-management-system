package Models;

public class ReaderModel {

}
