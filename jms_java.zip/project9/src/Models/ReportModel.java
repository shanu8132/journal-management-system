package Models;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import util.ConnectionProvider;
import LoginServlet.ViewReport;

public class ReportModel {
	
	private String range,content,addedvalue,publishprev,papervol,importance,researchtype,result;

	public String getRange() {
		return range;
	}

	public void setRange(String range) {
		this.range = range;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getAddedvalue() {
		return addedvalue;
	}

	public void setAddedvalue(String addedvalue) {
		this.addedvalue = addedvalue;
	}

	public String getPublishprev() {
		return publishprev;
	}

	public void setPublishprev(String publishprev) {
		this.publishprev = publishprev;
	}

	public String getPapervol() {
		return papervol;
	}

	public void setPapervol(String papervol) {
		this.papervol = papervol;
	}

	public String getImportance() {
		return importance;
	}

	public void setImportance(String importance) {
		this.importance = importance;
	}

	public String getResearchtype() {
		return researchtype;
	}

	public void setResearchtype(String researchtype) {
		this.researchtype = researchtype;
	}

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}
	
	
	ArrayList<ReportModel> list2=new ArrayList<>();
	public ArrayList<ReportModel> getReport(int id){
	
	try{
		
		
		Connection conn=ConnectionProvider.getConn();
		PreparedStatement ps=conn.prepareStatement("select range,content,addedvalue,publishprev,papervol,importance,researchtype,result from reviewjournal where id=?");
		ps.setInt(1, id);
		ResultSet rs=ps.executeQuery();
		while(rs.next()){
			
			
			ReportModel rep=new ReportModel();
			rep.range=rs.getString(1);
			rep.content=rs.getString(2);
			rep.addedvalue=rs.getString(3);
			rep.publishprev=rs.getString(4);
			rep.papervol=rs.getString(5);
			rep.importance=rs.getString(6);
			rep.researchtype=rs.getString(7);
			rep.result=rs.getString(8);
			
			list2.add(rep);
		}
	}
	catch(Exception e){
		e.printStackTrace();
	}
	return list2;


}

}
