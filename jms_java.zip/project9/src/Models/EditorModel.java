package Models;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import util.ConnectionProvider;

public class EditorModel {
	private int id;
	private String uname;
	

	private String upass;
	private String lname;
	private String fname;
	private String email;
	private String specialization;

	public String getSpecialization() {
		return specialization;
	}
	public void setSpecialization(String specialization) {
		this.specialization = specialization;
	}

	private String gender;
	private String dob;
	

	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public String getUname() {
		return uname;
	}
	public void setUname(String uname) {
		this.uname = uname;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}

	String tablename = "usertable";
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getUpass() {
		return upass;
	}
	public void setUpass(String upass) {
		this.upass = upass;
	}
	public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	
	String m;
	int edid;
	public int validate(){
		try {
			Connection conn = ConnectionProvider.getConn();
			PreparedStatement ps = conn.prepareStatement("select * from editor where Email=? and Password=?");
			ps.setString(1, email);
			ps.setString(2, upass);
			ResultSet rs = ps.executeQuery();
			if(rs.next()){
				System.out.println("I m here in if ");
				edid=rs.getInt(1);
			}
			else{
				System.out.println("I m here in else");
				edid=0;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return edid;
	}
	public String register(){
		try {
			Connection conn=ConnectionProvider.getConn();
			
			PreparedStatement ps = conn.prepareStatement("insert into editor values(editorseq.nextval,?,?,?,?,?,?,?)");
			ps.setString(1, fname);
			ps.setString(2, lname);
			ps.setString(3, email);
			ps.setString(4,upass);
			ps.setString(5,dob);
			ps.setString(6,specialization);
			ps.setString(7,gender);
			
			int i = ps.executeUpdate();
				if(i==0){
					m="failed";
				}
				else{
					m="success";
						
				}
		} catch (Exception e) {
			
			e.printStackTrace();
		}
		return m;
	}
	List<EditorModel> list=new ArrayList<EditorModel>();
	public List<EditorModel> getEditorDetails(String aSpec){
		try{
		System.out.println("In Model Author Specialization : "+aSpec);
		Connection conn=ConnectionProvider.getConn();
		PreparedStatement ps=conn.prepareStatement("select * from editor where specialization=?");
		ps.setString(1,aSpec);
		ResultSet rs=ps.executeQuery();
		while(rs.next()){
			System.out.println("I m in Loop");
			int id=rs.getInt(1);
			String fname=rs.getString(2);
			String lname=rs.getString(3);
			String email=rs.getString(4);
			String pass=rs.getString(5);
			String dob=rs.getString(6);
			String sp=rs.getString(7);
			String g=rs.getString(8);
			
			EditorModel em=new EditorModel();
			em.setDob(dob);
			em.setEmail(email);
			em.setFname(fname);
			em.setLname(lname);
			em.setGender(g);
			em.setSpecialization(sp);
			em.setUpass(pass);
			em.setId(id);
			
			list.add(em);
			
		}
		}
		catch(Exception e){e.printStackTrace();}
		return list;
	}
	String spec1="none";
	public String getSpecialization(int id){
		try{
			System.out.println("Editor Id in Model : "+id);
			Connection conn=ConnectionProvider.getConn();
			PreparedStatement ps=conn.prepareStatement("select specialization from editor where Editorid=?");
			ps.setInt(1,id);
			ResultSet rs=ps.executeQuery();
			if(rs.next()){
			spec1=rs.getString(1);	
			}
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return spec1;
	

}
	String name;
	public String getEditorName(int editorid){
		
		try{			Connection conn=ConnectionProvider.getConn();
		PreparedStatement ps=conn.prepareStatement("select firstname,lastname from editor where editorid=?");
		ps.setInt(1,editorid);
		ResultSet rs=ps.executeQuery();
		if(rs.next()){
			name=rs.getString(1)+" "+rs.getString(2);
		}
			
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return name;
	}
}
