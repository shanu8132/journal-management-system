package Models;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import javax.servlet.http.HttpSession;

import util.ConnectionProvider;

public class UserModel implements Serializable {
	private String uname;
	private String upass;
	private String lname;
	private String fname;
	private String email;
	private String specialization;
	private String gender;
	private String dob;
	int aid;

	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getSpecialization() {
		return specialization;
	}
	public void setSpecialization(String specialization) {
		this.specialization = specialization;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}

	String tablename = "usertable";
	
	public String getUname() {
		return uname;
	}
	public void setUname(String uname) {
		this.uname = uname;
	}
	public String getUpass() {
		return upass;
	}
	public void setUpass(String upass) {
		this.upass = upass;
	}
	public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	
	int i;
	public int validate(){
		try {
			Connection conn = ConnectionProvider.getConn();
			System.out.println("inside calidate");
			PreparedStatement ps = conn.prepareStatement("select * from author where Email=? and Password=?");
			ps.setString(1, email);
			ps.setString(2, upass);
			ResultSet rs = ps.executeQuery();
			if(rs.next()){
				i=rs.getInt(1);
				System.out.println("I m here in if");
				
			}
			else{
				
				i=0;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return i;
	}
	String m;
	public String register(){
		try {
			Connection conn=ConnectionProvider.getConn();
			
			PreparedStatement ps = conn.prepareStatement("insert into author values(authorseq.nextval,?,?,?,?,?,?,?)");
			ps.setString(1, fname);
			ps.setString(2, lname);
			ps.setString(3, email);
			ps.setString(4,upass);
			ps.setString(5,dob);
			ps.setString(6,specialization);
			ps.setString(7,gender);
			int i = ps.executeUpdate();
				if(i==0){
					m="failed";
				}
				else{
					m="success";
						
				}
		} catch (Exception e) {
			
			e.printStackTrace();
		}
		return m;
	}
	String spec="none";
	public String getSpecialization(int id){
		try{
			System.out.println("Author Id in Model : "+id);
			Connection conn=ConnectionProvider.getConn();
			PreparedStatement ps=conn.prepareStatement("select specialization from author where authorid=?");
			ps.setInt(1,id);
			ResultSet rs=ps.executeQuery();
			if(rs.next()){
			spec=rs.getString(1);	
			}
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return spec;
	}
	public String changepass(int id){
		
		
		try {Connection conn=ConnectionProvider.getConn();
				
		PreparedStatement ps = 
		conn.prepareStatement
		("update author set password=? where authorid=?");
				ps.setString(1,getUpass());
				ps.setInt(2,id);
				int i = ps.executeUpdate();
				if(i==0){
					m="failed";
					System.out.println("here in password failed");
				}
				else{
					m="success";
					System.out.println("here in password success");
				}
					
				} catch (Exception e) {
					e.printStackTrace();
				}
				return m;
			}
	
	
	
	public int getAid() {
		return aid;
	}
	public void setAid(int aid) {
		this.aid = aid;
	}
	public String getAuthorName(int id) {
		
		try {Connection conn=ConnectionProvider.getConn();
		
		PreparedStatement ps = 
		conn.prepareStatement
		("select firstname,lastname from author where authorid=?");
				ps.setInt(1,id);
				ResultSet rs=ps.executeQuery();
				if(rs.next()){
					m=rs.getString(1)+" "+rs.getString(2);
					System.out.println("here in password failed");
				}
				else{
					m="Not Found";
					System.out.println("here in password success");
				}
					
				} catch (Exception e) {
					e.printStackTrace();
				}
				return m;
		
	}
	String name;
	public String getEditorName(int authorid){
		
		try{			Connection conn=ConnectionProvider.getConn();
		PreparedStatement ps=conn.prepareStatement("select firstname,lastname from author where authorid=?");
		ps.setInt(1,authorid);
		ResultSet rs=ps.executeQuery();
		if(rs.next()){
			name=rs.getString(1)+" "+rs.getString(2);
		}
			
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return name;
	}
	
	
	ArrayList<UserModel> authorlist=new ArrayList();
	public ArrayList<UserModel> getAuthorList(){
		try{
			Connection conn=ConnectionProvider.getConn();
			PreparedStatement ps1=conn.prepareStatement("select authorid,firstname,lastname from author");
			ResultSet rs=ps1.executeQuery();
			while(rs.next()){
				UserModel um=new UserModel();
				um.aid=rs.getInt(1);
				um.fname=rs.getString(2);
				um.lname=rs.getString(3);
				System.out.println("AUTHOR ID :"+um.aid);
				System.out.println("AUTHOR FName :"+um.fname);
				System.out.println("AUTHOR LName :"+um.lname);
				
				
				
				authorlist.add(um);
			}
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return authorlist;
	}
	

}
