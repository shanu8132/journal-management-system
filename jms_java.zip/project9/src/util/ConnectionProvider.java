package util;

import java.sql.Connection;
import java.sql.DriverManager;



public class ConnectionProvider {
	private ConnectionProvider(){}
	static Connection conn = null;
	public static Connection getConn(){
			try {
				Class.forName("oracle.jdbc.driver.OracleDriver");
				conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1522:xe","system","12345");
				} 
			catch (Exception e) {
			e.printStackTrace();
		}
			return conn;
	}
}
	
